export const environment = {

  YOUR_GOOGLE_MAPS_API_KEY: 'AIzaSyApo98kj_iEowsLsb7oYHuRojfluMVXze8',
  YOUR_OPENWEATHER_API_KEY: '7b426527a4bb6a8d6c2e64a2d421d7e4'
}

export const { YOUR_GOOGLE_MAPS_API_KEY, YOUR_OPENWEATHER_API_KEY } = environment;